This file exists to ensure the directory will be created when creating tar.gz.

Put all of your shell scripts into this directory.